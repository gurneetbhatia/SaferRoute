package com.example.inderdeepbhatia.mugmap3;

import com.google.android.gms.maps.model.LatLng;
import java.util.*;
import java.net.*;
import java.io.*;
import org.json.*;
import java.sql.*;

public class PoliceAPI {

    static Dictionary<String, Integer> safe_rate = new Hashtable<>();

    public static LatLng[] getSafestPath(ArrayList<LatLng[]> paths){

        //Show an alert saying: Your safety is our primary concern. We may take some time to find a path for you, but we assure you that it will be best for you!

        ArrayList<Double> safetyRatings = new ArrayList<>();
        safe_rate.put("public order", 2);

        safe_rate.put("shoplifting", 3);

        safe_rate.put("criminal damage", 4);

        safe_rate.put("other theft"+"other crime", 6);

        safe_rate.put("vehicle crime", 6);

        safe_rate.put("bike theft", 7);

        safe_rate.put("burglary", 8);

        safe_rate.put("drugs", 9);

        safe_rate.put("violent crime"+"theft from a person"+"possession of weapons", 10);

        //the safety ratings from crime stats carry a weight of 75% while the rating provided by the user carry 25%

        for(LatLng[] path: paths){
            safetyRatings.add(getSafetyRating(path)*0.75);
        }

        
        int minIndex = safetyRatings.indexOf(Collections.min(safetyRatings));

        return paths.get(minIndex);

    }

    public static String convertStreamToString(InputStream is) {
        @SuppressWarnings("resource")
        java.util.Scanner s = new Scanner(is).useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    }

    static double getSafetyRating(LatLng[] path) {

        ArrayList<Integer> ids = new ArrayList<>();//arrayList containing the ids of all the used crimes for this calculation only
        double totalSafety = 0.0;
        for (LatLng point : path) {

            //for each point, get the safety rating and add it to the totalSafety for the route
            //also need to make sure that i don't count the same crime twice (in case it is close to two waypoints)
            //https://data.police.uk/api/crimes-street/all-crime?lat=52.629729&lng=-1.131592
            String url = "https://data.police.uk/api/crimes-street/all-crime?lat="+point.latitude+"&lng="+point.longitude;
            try {
                URI url1 = new URI(url);

                InputStream i = url1.toURL().openStream();
                JSONArray root = new JSONArray(convertStreamToString(i));
                for(int x = 0;x<root.length();x++){

                    JSONObject obj = (JSONObject) root.get(x);
                    if(!ids.contains(obj.get("id"))){
                        ids.add(obj.getInt("id"));
                        //unique id found
                        //find the corresponding crime rating for the given crime category now
                        try {
                            totalSafety += safe_rate.get(obj.getString("category"));
                        } catch(NullPointerException e){
                            continue;
                        }


                    }
                }




            } catch(Exception e){
                e.printStackTrace();
            }

        }
        return totalSafety;
    }
}
