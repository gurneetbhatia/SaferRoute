package com.example.inderdeepbhatia.mugmap3;

import com.google.android.gms.maps.model.LatLng;
import java.util.*;
import java.net.*;
import java.io.*;
import org.json.*;
import android.os.*;

public class DirectionsData {

    public static String convertStreamToString(InputStream is) {

        java.util.Scanner s = new Scanner(is).useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    }

    public static ArrayList<LatLng[]> getMarkers(LatLng origin, LatLng destination){

        ArrayList<LatLng[]> markers = new ArrayList<>();
        String url = "https://maps.googleapis.com/maps/api/directions/json?origin="+origin.latitude+","+origin.longitude+"&destination="+destination.latitude+","+destination.longitude+"&key=AIzaSyA0ngRDFqK8EGzu8FEwM9OgU-bQ-pi2QOY";
        HttpURLConnection conn = null;
        try{
            //JSONObject root = new RetrieveFeedTask().execute(url);

            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

            StrictMode.setThreadPolicy(policy);

            JSONObject root = null;
            URL url1 = new URL(url);
            conn = (HttpURLConnection) url1.openConnection();
            try {
                InputStream in = new BufferedInputStream(conn.getInputStream());
                //readStream(in);

                root = new JSONObject(convertStreamToString(conn.getInputStream()));
            } finally {
                conn.disconnect();
            }

            JSONArray routes = root.getJSONArray("routes");//an array of json objects. each object is a route


            for(int x = 0;x<routes.length();x++) {

                JSONObject route = routes.getJSONObject(x);
                JSONArray legs = route.getJSONArray("legs");
                JSONObject object = legs.getJSONObject(0);
                JSONArray steps = object.getJSONArray("steps");
                LatLng[] coords = new LatLng[steps.length()+1];
                coords[0] = new LatLng(origin.latitude, origin.longitude);
                for (int c = 0; c < steps.length(); c++) {
                    JSONObject obj = (JSONObject) steps.get(c);
                    //String s = obj.getJSONObject("end_location").get("lat") + "," + obj.getJSONObject("end_location").get("lng");
                    coords[c+1] = new LatLng(obj.getJSONObject("end_location").getDouble("lat"), obj.getJSONObject("end_location").getDouble("lng"));
                    /**Right now we are only storing the lat and lng of the next step, while the html text bit is also just as impotant
                     * once you get the basics working, try to work on the logitics of showing the path to the user (guiding them)*/


                }
                markers.add(coords);
            }

        }
        catch(Exception e) {
            //e.printStackTrace();
        }
        finally {
            conn.disconnect();
        }

        return markers;



    }

}
