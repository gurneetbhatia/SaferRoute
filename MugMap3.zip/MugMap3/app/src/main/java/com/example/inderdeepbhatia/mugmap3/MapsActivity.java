package com.example.inderdeepbhatia.mugmap3;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends FragmentActivity
        implements GoogleMap.OnMyLocationButtonClickListener,
        GoogleMap.OnMyLocationClickListener,
        OnMapReadyCallback{

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // TODO: Before enabling the My Location layer, you must request
        // location permission from the user. This sample does not include
        // a request for location permission.
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                String[] arr = new String[2];
                arr[0] = Manifest.permission.ACCESS_COARSE_LOCATION;
                arr[1] = Manifest.permission.ACCESS_FINE_LOCATION;
                requestPermissions(arr, 177);
            }
            return;
        }
        /*mMap.setMyLocationEnabled(true);
        mMap.setOnMyLocationButtonClickListener(this);
        mMap.setOnMyLocationClickListener(this);*/
    }

    @Override
    public boolean onMyLocationButtonClick() {
        return false;
    }

    @Override
    public void onMyLocationClick(@NonNull Location location) {

    }

    public void onMapSearch(View view) {
        /**When you click search right now without typing out the whole place name or maybe just spelling it incorrectly,
         *  the app crashes. Instead handle this error and show an apt message*/
        mMap.clear();
        EditText locationSearch = findViewById(R.id.editText);
        String location = locationSearch.getText().toString();
        List<Address> addressList = null;

        if (location != null || !location.equals("")) {
            Geocoder geocoder = new Geocoder(this);
            try {
                addressList = geocoder.getFromLocationName(location, 1);

            } catch (IOException e) {
                e.printStackTrace();
            }
            Address address = addressList.get(0);
            LatLng destination = new LatLng(address.getLatitude(), address.getLongitude());
            mMap.addMarker(new MarkerOptions().position(destination).title("Destination"));
            mMap.animateCamera(CameraUpdateFactory.newLatLng(destination));

            LatLng origin = new LatLng(51.501476, -0.140634);//let this be the current location
            mMap.addMarker(new MarkerOptions().position(origin).title("Origin"));
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(origin, 10.0f));

            System.out.println("Origin: "+origin.latitude+","+origin.longitude);
            System.out.println("Destination: "+destination.latitude+","+destination.longitude);
            ArrayList<LatLng[]> paths = DirectionsData.getMarkers(origin, destination);
            /**Find the safest path now*/
            LatLng[] bestPath = PoliceAPI.getSafestPath(paths);
            for (LatLng l : bestPath) {
                draw(l);
            }
            for(int i=1;i<bestPath.length;i++){
                //connect i-1 and i
                Polyline line = mMap.addPolyline(new PolylineOptions()
                        .add(bestPath[i-1],
                                bestPath[i]));
            }



            /*if(data.size()>0) {
                LatLng[] testArr = data.get(0);
                for (LatLng l : testArr) {
                    draw(l);
                }
                for(int i=1;i<testArr.length;i++){
                    //connect i-1 and i
                    Polyline line = mMap.addPolyline(new PolylineOptions()
                    .add(testArr[i-1],
                            testArr[i]));
                }
            }
            else {
                System.out.println("No data on routes was returned");
            }*/


        }
    }

    public void draw(LatLng point){
        mMap.addCircle(new CircleOptions()
                .center(point)
                .radius(10)
                .strokeColor(Color.BLUE)
                .fillColor(Color.BLUE));
    }
}
